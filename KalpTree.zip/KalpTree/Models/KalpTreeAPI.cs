﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KalpTree.Models
{
    public class KalpTreeAPI
    {
        public string LoginApiUrl { get; set; }
    }
}
